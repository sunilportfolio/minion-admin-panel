// Enhanced Add Product JavaScript with updated functionality

document.addEventListener("DOMContentLoaded", () => {
  checkAdminAuth()
  initializeAddProductPage()
})

// Enhanced Categories data structure with main categories
const categoriesData = {
  Tech: {
    "Smart Home Controllers": [
      "Voice Control Systems",
      "Smart Switches",
      "Smart Dimmers",
      "Motion Sensors",
      "Smart Plugs",
      "Hub Controllers",
      "Wireless Controllers",
      "Touch Panel Controllers",
    ],
    "Security Systems": [
      "Smart Cameras",
      "Door Locks",
      "Alarm Systems",
      "Access Control",
      "Intercom Systems",
      "Smart Doorbells",
      "Security Sensors",
    ],
    "Entertainment Systems": ["Smart TVs", "Sound Systems", "Projectors", "Gaming Setup", "Streaming Devices"],
  },
  Automation: {
    "Lighting Automation": [
      "Automated Light Controls",
      "Scene Controllers",
      "Timer Switches",
      "Daylight Sensors",
      "Smart Bulbs",
      "LED Strip Controllers",
    ],
    "Climate Control": [
      "Smart Thermostats",
      "Automated Fans",
      "Temperature Sensors",
      "Humidity Controllers",
      "HVAC Controllers",
    ],
    "Window Automation": ["Motorized Blinds", "Smart Curtains", "Window Sensors", "Automated Shutters"],
  },
  Lighting: {
    "Decorative Lighting": [
      "Chandeliers",
      "Pendant Lights",
      "Wall Sconces",
      "Table Lamps",
      "Floor Lamps",
      "LED Strips",
      "Accent Lighting",
      "Mood Lighting",
    ],
    "Functional Lighting": [
      "Ceiling Lights",
      "Recessed Lighting",
      "Track Lighting",
      "Under Cabinet Lighting",
      "Task Lighting",
      "Emergency Lighting",
    ],
    "Outdoor Lighting": ["Garden Lights", "Pathway Lighting", "Security Lighting", "Facade Lighting", "Pool Lighting"],
  },
  Flooring: {
    "Smart Flooring": [
      "Heated Floors",
      "Smart Tiles",
      "Interactive Flooring",
      "LED Floor Panels",
      "Pressure Sensitive Floors",
    ],
    "Traditional Flooring": [
      "Wooden Flooring",
      "Laminate Flooring",
      "Vinyl Flooring",
      "Carpet Tiles",
      "Stone Flooring",
      "Ceramic Tiles",
    ],
  },
  Ceiling: {
    "Decorative Wall Panels": [
      "3D PVC Wall Panels",
      "MDF Decorative Panels",
      "Gypsum 3D Wall Panels",
      "Acrylic Wall Panels",
      "Wooden Laminate Panels",
      "Stone Veneer Panels",
      "Marble Finish Panels",
      "Concrete Finish Panels",
      "Brick Cladding Panels",
      "Laser Cut Panels",
      "PU Leather Panels",
      "Metal Wall Cladding Panels",
      "Bamboo Panels",
      "Fabric-Wrapped Panels",
      "Faux Brick Panels",
      "Faux Stone Panels",
      "Custom Logo Panels",
      "MDF Grooved Panels",
      "Recycled Wood Panels",
      "Charcoal Wall Panels",
    ],
    "Ceiling Systems": [
      "False Ceiling",
      "Suspended Ceiling",
      "Coffered Ceiling",
      "Tray Ceiling",
      "Acoustic Ceiling",
      "LED Ceiling Panels",
      "Smart Ceiling Systems",
    ],
  },
  Cooling: {
    "Air Conditioning": [
      "Split AC Systems",
      "Central AC",
      "Portable AC Units",
      "Window AC",
      "Inverter AC",
      "Smart AC Controllers",
    ],
    "Fans & Ventilation": [
      "Ceiling Fans",
      "Wall Fans",
      "Exhaust Fans",
      "Ventilation Systems",
      "Smart Fans",
      "Industrial Fans",
    ],
    "Cooling Accessories": ["Air Purifiers", "Humidifiers", "Dehumidifiers", "Air Coolers", "Cooling Pads"],
  },
}

// Initialize Enhanced Category Tree with main categories - FIXED VERSION
function initializeCategoryTree() {
  const categoryTree = document.getElementById("category-tree")

  if (!categoryTree) {
    console.error("Category tree element not found!")
    return
  }

  let html = ""

  Object.keys(categoriesData).forEach((mainCategory) => {
    html += `
      <div class="main-category-group">
        <div class="main-category-header" onclick="toggleMainCategory(this)">
          <span class="category-arrow">▶</span>
          <strong>${mainCategory}</strong>
        </div>
        <div class="main-category-content">
    `

    Object.keys(categoriesData[mainCategory]).forEach((category) => {
      html += `
        <div class="category-group">
          <div class="category-header" onclick="toggleCategory(this)">
            <span class="category-arrow">▶</span>
            ${category}
          </div>
          <div class="subcategories">
            ${categoriesData[mainCategory][category]
              .map(
                (subcategory) =>
                  `<div class="subcategory-item" onclick="selectSubcategory(this, '${mainCategory}', '${category}', '${subcategory}')">${subcategory}</div>`,
              )
              .join("")}
          </div>
        </div>
      `
    })

    html += `
        </div>
      </div>
    `
  })

  categoryTree.innerHTML = html
  console.log("Category tree initialized successfully")
}

// Global variables for photo management
const uploadedPhotos = new Map() // Store photo data with index as key
let photoCount = 1 // Start with 1 for primary photo

// Authentication check
function checkAdminAuth() {
  if (typeof window.auth !== "undefined") {
    window.auth.onAuthStateChanged((user) => {
      if (!user) {
        console.log("No user authenticated, but continuing for development")
        return
      }
      document.getElementById("adminUserName").textContent = user.displayName || user.email || "Admin"
    })
  }
}

// Update the initialization function to ensure category tree loads
function initializeAddProductPage() {
  console.log("Initializing add product page...")

  const form = document.getElementById("add-product-form")
  if (form) {
    form.addEventListener("submit", handleAddProduct)
  }

  setupImagePreview("primary-photo", "primary-photo-preview")
  initializeRichTextEditor()

  // Initialize category tree with a small delay to ensure DOM is ready
  setTimeout(() => {
    initializeCategoryTree()
  }, 100)

  initializeEnhancedColors()
  updatePhotoCounter()

  console.log("Add product page initialized")
}

// Quantity control functions
window.increaseQuantity = () => {
  const quantityInput = document.getElementById("product-quantity")
  const currentValue = Number.parseInt(quantityInput.value) || 1
  quantityInput.value = currentValue + 1
}

window.decreaseQuantity = () => {
  const quantityInput = document.getElementById("product-quantity")
  const currentValue = Number.parseInt(quantityInput.value) || 1
  if (currentValue > 1) {
    quantityInput.value = currentValue - 1
  }
}

// Initialize Rich Text Editor
function initializeRichTextEditor() {
  const toolbar = document.querySelector(".editor-toolbar")
  const editor = document.getElementById("product-description-editor")
  const hiddenInput = document.getElementById("product-description")

  toolbar.addEventListener("click", (e) => {
    if (e.target.classList.contains("editor-btn")) {
      e.preventDefault()
      const command = e.target.dataset.command

      if (command === "fontSize") {
        document.execCommand(command, false, e.target.value)
      } else if (command === "foreColor") {
        document.execCommand(command, false, e.target.value)
      } else {
        document.execCommand(command, false, null)
      }

      e.target.classList.toggle("active")
      editor.focus()
    }
  })

  toolbar.addEventListener("change", (e) => {
    if (e.target.dataset.command) {
      const command = e.target.dataset.command
      document.execCommand(command, false, e.target.value)
      editor.focus()
    }
  })

  editor.addEventListener("input", () => {
    hiddenInput.value = editor.innerHTML
  })
}

// Make sure these functions are properly defined in global scope
window.toggleMainCategory = (header) => {
  const group = header.parentElement
  group.classList.toggle("expanded")
  console.log("Main category toggled:", group.classList.contains("expanded"))
}

window.toggleCategory = (header) => {
  const group = header.parentElement
  group.classList.toggle("expanded")
  console.log("Category toggled:", group.classList.contains("expanded"))
}

window.selectSubcategory = (element, mainCategory, category, subcategory) => {
  console.log("Subcategory selected:", mainCategory, category, subcategory)

  // Remove previous selection
  document.querySelectorAll(".subcategory-item.selected").forEach((item) => {
    item.classList.remove("selected")
  })

  // Add selection to clicked item
  element.classList.add("selected")

  // Update hidden inputs
  document.getElementById("selected-main-category").value = mainCategory
  document.getElementById("selected-category").value = category
  document.getElementById("selected-subcategory").value = subcategory

  console.log("Selection updated in hidden inputs")
}

// Specifications functions
window.switchSpecTab = (button, tabType) => {
  // Remove active class from all tabs
  document.querySelectorAll(".spec-tab").forEach((tab) => {
    tab.classList.remove("active")
  })

  // Add active class to clicked tab
  button.classList.add("active")

  // Hide all spec contents
  document.querySelectorAll(".spec-content").forEach((content) => {
    content.style.display = "none"
  })

  // Show selected spec content
  document.getElementById(tabType + "-specs").style.display = "block"
}

window.addSpecRow = (specType) => {
  const tableId = specType + "-spec-table"
  const table = document.getElementById(tableId).getElementsByTagName("tbody")[0]

  const newRow = table.insertRow()
  newRow.innerHTML = `
    <td class="spec-label">
      <input type="text" placeholder="Specification name" style="width: 100%; border: none; background: transparent; font-weight: 500;">
    </td>
    <td class="spec-value">
      <input type="text" name="spec_custom_${Date.now()}" placeholder="Enter value">
      <button type="button" onclick="removeSpecRow(this)" style="background: #ef4444; color: white; border: none; border-radius: 4px; padding: 4px 8px; margin-left: 8px; cursor: pointer;">×</button>
    </td>
  `
}

window.removeSpecRow = (button) => {
  const row = button.closest("tr")
  row.remove()
}

// Enhanced Color Functions
window.addEnhancedColor = () => {
  const colorsList = document.getElementById("color-items-list")
  const colorItem = document.createElement("div")
  colorItem.className = "color-item-enhanced"
  colorItem.innerHTML = `
    <div class="color-photo-section">
      <label>Color Image</label>
      <input type="file" accept="image/*" class="color-photo-input" onchange="handleColorPhoto(this)">
      <div class="color-photo-preview">Click to add image</div>
      <input type="url" placeholder="Or enter image URL" class="color-photo-url" onchange="handleColorPhotoURL(this)">
    </div>
    <div class="color-details-section">
      <input type="text" placeholder="Color name (e.g., Marble White, Oak Wood)" class="color-name" />
      <textarea placeholder="Color description/note" class="color-description" rows="2"></textarea>
    </div>
    <button type="button" class="remove-color-btn" onclick="removeEnhancedColor(this)">×</button>
  `
  colorsList.appendChild(colorItem)
}

window.removeEnhancedColor = (button) => {
  const colorItem = button.parentElement
  const colorsList = document.getElementById("color-items-list")

  if (colorsList.children.length > 1) {
    colorItem.remove()
  } else {
    // Clear the inputs instead of removing the item
    const nameInput = colorItem.querySelector(".color-name")
    const descInput = colorItem.querySelector(".color-description")
    const preview = colorItem.querySelector(".color-photo-preview")

    nameInput.value = ""
    descInput.value = ""
    preview.innerHTML = "Click to add image"
    preview.style.backgroundImage = ""
  }
}

window.handleColorPhoto = (input) => {
  const file = input.files[0]
  if (file) {
    const reader = new FileReader()
    reader.onload = (e) => {
      const preview = input.parentElement.querySelector(".color-photo-preview")
      preview.innerHTML = `<img src="${e.target.result}" alt="Color photo">`

      // Store file data for later upload
      input.parentElement.dataset.fileData = JSON.stringify({
        name: file.name,
        data: e.target.result,
        file: file,
        type: "file",
      })
    }
    reader.readAsDataURL(file)
  }
}

window.handleColorPhotoURL = (input) => {
  const url = input.value.trim()
  if (url) {
    const preview = input.parentElement.querySelector(".color-photo-preview")
    preview.innerHTML = `<img src="${url}" alt="Color photo" onerror="this.parentElement.innerHTML='Invalid image URL'">`

    // Store URL data
    input.parentElement.dataset.fileData = JSON.stringify({
      url: url,
      type: "url",
    })
  }
}

// Enhanced Photo Upload Functions - Support for 10 photos
window.toggleAdditionalPhotos = () => {
  const container = document.getElementById("additional-photos-container")
  const button = document.querySelector(".additional-photos-btn")

  if (container.style.display === "none") {
    container.style.display = "block"
    button.innerHTML = `<span>📷</span> Hide Additional Photos`
  } else {
    container.style.display = "none"
    button.innerHTML = `<span>📷</span> Additional Photos (Optional - up to 10 photos total)`
  }
}

window.triggerPhotoUpload = (index) => {
  const photoItem = document.querySelector(`[data-index="${index}"]`)
  const fileInput = photoItem.querySelector('input[type="file"]')
  fileInput.click()
}

window.handlePhotoUpload = (input, index) => {
  const file = input.files[0]
  if (file) {
    const reader = new FileReader()
    reader.onload = (e) => {
      const photoItem = input.parentElement
      const photoSlot = photoItem.querySelector(".photo-slot")
      const removeBtn = photoItem.querySelector(".remove-photo-btn")
      const urlInput = photoItem.querySelector(".photo-url-input")

      // Update photo slot
      photoSlot.innerHTML = `<img src="${e.target.result}" alt="Product photo ${index + 2}">`
      photoSlot.classList.add("has-image")

      // Show remove button
      removeBtn.style.display = "flex"

      // Clear URL input
      urlInput.value = ""

      // Store photo data
      uploadedPhotos.set(index, {
        name: file.name,
        data: e.target.result,
        file: file,
        type: "file",
      })

      updatePhotoCounter()
    }
    reader.readAsDataURL(file)
  }
}

window.handlePhotoURL = (input, index) => {
  const url = input.value.trim()
  if (url) {
    const photoItem = input.parentElement
    const photoSlot = photoItem.querySelector(".photo-slot")
    const removeBtn = photoItem.querySelector(".remove-photo-btn")
    const fileInput = photoItem.querySelector('input[type="file"]')

    // Update photo slot
    photoSlot.innerHTML = `<img src="${url}" alt="Product photo ${index + 2}" onerror="this.parentElement.innerHTML='<span class=\\'upload-icon\\'>×</span><span class=\\'upload-text\\'>Invalid URL</span>'; this.parentElement.classList.remove('has-image')">`
    photoSlot.classList.add("has-image")

    // Show remove button
    removeBtn.style.display = "flex"

    // Clear file input
    fileInput.value = ""

    // Store photo data
    uploadedPhotos.set(index, {
      url: url,
      type: "url",
    })

    updatePhotoCounter()
  }
}

window.removePhoto = (index) => {
  const photoItem = document.querySelector(`[data-index="${index}"]`)
  const photoSlot = photoItem.querySelector(".photo-slot")
  const removeBtn = photoItem.querySelector(".remove-photo-btn")
  const fileInput = photoItem.querySelector('input[type="file"]')
  const urlInput = photoItem.querySelector(".photo-url-input")

  // Reset photo slot
  photoSlot.innerHTML = `
    <span class="upload-icon">+</span>
    <span class="upload-text">Photo ${index + 2}</span>
  `
  photoSlot.classList.remove("has-image")

  // Hide remove button
  removeBtn.style.display = "none"

  // Clear inputs
  fileInput.value = ""
  urlInput.value = ""

  // Remove from uploaded photos
  uploadedPhotos.delete(index)

  updatePhotoCounter()
}

// Handle primary photo URL
window.handlePrimaryPhotoURL = () => {
  const urlInput = document.getElementById("primary-photo-url")
  const preview = document.getElementById("primary-photo-preview")
  const url = urlInput.value.trim()

  if (url) {
    preview.innerHTML = `<img src="${url}" alt="Primary photo" onerror="this.parentElement.innerHTML='<span class=\\'empty\\'>Invalid image URL</span>'; this.parentElement.classList.add('empty')">`
    preview.classList.remove("empty")

    // Clear file input if URL is provided
    document.getElementById("primary-photo").value = ""
  }
}

// Update photo counter
function updatePhotoCounter() {
  const counter = document.getElementById("photo-count")
  const totalPhotos = 1 + uploadedPhotos.size // 1 for primary + additional photos
  counter.textContent = totalPhotos
  photoCount = totalPhotos
}

// Select payment option function
window.selectPaymentOption = (element, value) => {
  // Remove selected class from all options
  document.querySelectorAll(".payment-option").forEach((option) => {
    option.classList.remove("selected")
  })

  // Add selected class to clicked option
  element.classList.add("selected")

  // Check the radio button
  const radio = element.querySelector('input[type="radio"]')
  radio.checked = true
}

// Image preview setup
function setupImagePreview(inputId, previewId) {
  const input = document.getElementById(inputId)
  const preview = document.getElementById(previewId)

  preview.innerHTML = '<span class="empty">Image preview will appear here</span>'
  preview.classList.add("empty")

  input.addEventListener("change", (e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`
        preview.classList.remove("empty")

        // Clear URL input if file is selected
        const urlInput = document.getElementById(inputId + "-url")
        if (urlInput) urlInput.value = ""

        updatePhotoCounter()
      }
      reader.readAsDataURL(file)
    }
  })
}

// Show/hide loading overlay
function showLoading() {
  document.getElementById("loading-overlay").classList.add("active")
}

function hideLoading() {
  document.getElementById("loading-overlay").classList.remove("active")
}

// Show success message
function showSuccessMessage() {
  document.getElementById("success-message").classList.add("active")
}

// Hide success message
window.hideSuccessMessage = () => {
  document.getElementById("success-message").classList.remove("active")
  // Reset form
  document.getElementById("add-product-form").reset()

  // Reset rich text editor
  document.getElementById("product-description-editor").innerHTML = ""
  document.getElementById("product-description").value = ""

  // Reset category selection
  document.querySelectorAll(".subcategory-item.selected").forEach((item) => {
    item.classList.remove("selected")
  })
  document.getElementById("selected-main-category").value = ""
  document.getElementById("selected-category").value = ""
  document.getElementById("selected-subcategory").value = ""

  // Reset photos
  uploadedPhotos.clear()
  resetAllPhotos()

  // Reset colors
  initializeEnhancedColors()

  // Reset payment configuration
  document.querySelector('input[name="paymentConfig"][value="dont-sell-online"]').checked = true
  document.querySelectorAll(".payment-option").forEach((option) => {
    option.classList.remove("selected")
  })
  document.querySelector(".payment-option").classList.add("selected")

  // Reset image preview
  setupImagePreview("primary-photo", "primary-photo-preview")
  updatePhotoCounter()
}

// Reset all photos
function resetAllPhotos() {
  // Reset primary photo
  const primaryPreview = document.getElementById("primary-photo-preview")
  primaryPreview.innerHTML = '<span class="empty">Image preview will appear here</span>'
  primaryPreview.classList.add("empty")
  document.getElementById("primary-photo").value = ""
  document.getElementById("primary-photo-url").value = ""

  // Reset additional photos
  for (let i = 1; i <= 9; i++) {
    window.removePhoto(i)
  }
}

// Upload image to Firebase Storage (if Firebase is available)
async function uploadImage(file, folder) {
  if (typeof window.storage === "undefined") {
    console.warn("Firebase storage not available")
    return null
  }

  const timestamp = Date.now()
  const fileName = `${timestamp}_${file.name}`
  const storageRef = window.storage.ref(`${folder}/${fileName}`)

  try {
    const snapshot = await storageRef.put(file)
    const downloadURL = await snapshot.ref.getDownloadURL()
    return downloadURL
  } catch (error) {
    console.error("Error uploading image:", error)
    throw error
  }
}

// Process enhanced colors
async function processEnhancedColors() {
  const colors = []
  const colorItems = document.querySelectorAll(".color-item-enhanced")

  for (const item of colorItems) {
    const name = item.querySelector(".color-name").value.trim()
    const description = item.querySelector(".color-description").value.trim()
    const photoSection = item.querySelector(".color-photo-section")

    if (name) {
      const color = {
        name: name,
        description: description,
        imageUrl: null,
      }

      // Handle image upload or URL
      if (photoSection.dataset.fileData) {
        const fileData = JSON.parse(photoSection.dataset.fileData)

        if (fileData.type === "file" && fileData.file && typeof uploadImage === "function") {
          // Upload file to Firebase
          color.imageUrl = await uploadImage(fileData.file, "colors")
        } else if (fileData.type === "url") {
          // Use provided URL
          color.imageUrl = fileData.url
        }
      }

      colors.push(color)
    }
  }

  return colors
}

// Process all product photos (up to 10)
async function processProductPhotos() {
  const photos = []

  // Handle primary photo (required)
  const primaryImageFile = document.getElementById("primary-photo").files[0]
  const primaryImageURL = document.getElementById("primary-photo-url").value.trim()

  if (primaryImageFile && typeof uploadImage === "function") {
    const primaryUrl = await uploadImage(primaryImageFile, "products")
    photos.push(primaryUrl)
  } else if (primaryImageURL) {
    photos.push(primaryImageURL)
  } else {
    throw new Error("Primary image is required")
  }

  // Handle additional photos (up to 9 more)
  for (const [index, photoData] of uploadedPhotos.entries()) {
    if (photoData.type === "file" && photoData.file && typeof uploadImage === "function") {
      const url = await uploadImage(photoData.file, "products")
      photos.push(url)
    } else if (photoData.type === "url") {
      photos.push(photoData.url)
    }
  }

  return photos
}

// Process specifications
function processSpecifications() {
  const specifications = {
    technical: {},
    additional: {},
  }

  // Process technical specifications
  const technicalTable = document.getElementById("technical-spec-table")
  const technicalRows = technicalTable.querySelectorAll("tbody tr")

  technicalRows.forEach((row) => {
    const labelCell = row.querySelector(".spec-label")
    const valueCell = row.querySelector(".spec-value")

    let label = ""
    let value = ""

    // Get label
    const labelInput = labelCell.querySelector("input")
    if (labelInput) {
      label = labelInput.value.trim()
    } else {
      label = labelCell.textContent.trim()
    }

    // Get value
    const valueInput = valueCell.querySelector("input")
    const valueTextarea = valueCell.querySelector("textarea")

    if (valueInput) {
      value = valueInput.value.trim()
    } else if (valueTextarea) {
      value = valueTextarea.value.trim()
    }

    if (label && value) {
      specifications.technical[label] = value
    }
  })

  // Process additional specifications
  const additionalTable = document.getElementById("additional-spec-table")
  const additionalRows = additionalTable.querySelectorAll("tbody tr")

  additionalRows.forEach((row) => {
    const labelCell = row.querySelector(".spec-label")
    const valueCell = row.querySelector(".spec-value")

    let label = ""
    let value = ""

    // Get label
    const labelInput = labelCell.querySelector("input")
    if (labelInput) {
      label = labelInput.value.trim()
    } else {
      label = labelCell.textContent.trim()
    }

    // Get value
    const valueInput = valueCell.querySelector("input")
    const valueTextarea = valueCell.querySelector("textarea")

    if (valueInput) {
      value = valueInput.value.trim()
    } else if (valueTextarea) {
      value = valueTextarea.value.trim()
    }

    if (label && value) {
      specifications.additional[label] = value
    }
  })

  return specifications
}

// Handle add product with enhanced features and 10 photos
async function handleAddProduct(e) {
  e.preventDefault()
  showLoading()

  try {
    const formData = new FormData(e.target)

    // Process all product photos (up to 10)
    const allPhotos = await processProductPhotos()
    const primaryImageUrl = allPhotos[0]
    const additionalImageUrls = allPhotos.slice(1)

    // Process SEO tags
    const seoTagsString = formData.get("seoTags")
    const seoTags = seoTagsString ? seoTagsString.split(",").map((tag) => tag.trim()) : []

    // Process enhanced colors
    const enhancedColors = await processEnhancedColors()

    // Process specifications
    const specifications = processSpecifications()

    // Get payment configuration
    const paymentConfig = document.querySelector('input[name="paymentConfig"]:checked').value

    // Calculate discount percentage
    const currentPrice = Number.parseFloat(formData.get("currentPrice"))
    const originalPrice = Number.parseFloat(formData.get("originalPrice"))
    const discountPercent = originalPrice > 0 ? Math.round(((originalPrice - currentPrice) / originalPrice) * 100) : 0

    // Get rich text description
    const description =
      document.getElementById("product-description").value ||
      document.getElementById("product-description-editor").innerHTML

    // Prepare enhanced product data
    const productData = {
      name: formData.get("name"),
      description: description,
      currentPrice: currentPrice,
      originalPrice: originalPrice,
      priceUnit: formData.get("priceUnit"),
      discountPercent: discountPercent,
      mainCategory: document.getElementById("selected-main-category").value,
      category: document.getElementById("selected-category").value,
      subcategory: document.getElementById("selected-subcategory").value,
      brand: formData.get("brand") || null,
      stockStatus: formData.get("stockStatus"),
      material: formData.get("material"),
      dimensions: formData.get("dimensions"),
      thickness: formData.get("thickness"),
      quantity: Number.parseInt(formData.get("quantity")) || 1,
      enhancedColors: enhancedColors, // Enhanced colors with images
      specifications: specifications, // Technical and additional specifications
      primaryImageUrl: primaryImageUrl,
      additionalImageUrls: additionalImageUrls, // Up to 9 additional photos
      allPhotos: allPhotos, // All photos array (up to 10 total)
      photoCount: allPhotos.length, // Total photo count
      seoTags: seoTags, // SEO tags for better discoverability
      badge: formData.get("badge") || null,
      paymentConfig: paymentConfig,
      createdAt:
        typeof window.firebase !== "undefined" ? window.firebase.firestore.FieldValue.serverTimestamp() : new Date(),
      status: "active",
      shareCount: 0,
      viewCount: 0,
    }

    // Add to Firestore (if available)
    if (typeof window.db !== "undefined") {
      await window.db.collection("products").add(productData)
    } else {
      console.log("Product data prepared:", productData)
    }

    showSuccessMessage()
  } catch (error) {
    console.error("Error adding product:", error)
    alert("Error adding product: " + error.message)
  } finally {
    hideLoading()
  }
}

function initializeEnhancedColors() {
  const colorsList = document.getElementById("color-items-list")
  colorsList.innerHTML = `
    <div class="color-item-enhanced">
      <div class="color-photo-section">
        <label>Color Image</label>
        <input type="file" accept="image/*" class="color-photo-input" onchange="handleColorPhoto(this)">
        <div class="color-photo-preview">Click to add image</div>
        <input type="url" placeholder="Or enter image URL" class="color-photo-url" onchange="handleColorPhotoURL(this)">
      </div>
      <div class="color-details-section">
        <input type="text" placeholder="Color name (e.g., Marble White, Oak Wood)" class="color-name" />
        <textarea placeholder="Color description/note" class="color-description" rows="2"></textarea>
      </div>
      <button type="button" class="remove-color-btn" onclick="removeEnhancedColor(this)">×</button>
    </div>
  `
}

// Logout function
window.handleLogout = () => {
  if (confirm("Are you sure you want to logout?")) {
    if (typeof window.auth !== "undefined") {
      window.auth
        .signOut()
        .then(() => {
          window.location.href = "index.html"
        })
        .catch((error) => {
          console.error("Logout error:", error)
        })
    } else {
      window.location.href = "index.html"
    }
  }
}

// Keyboard shortcuts
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    window.hideSuccessMessage()
  }
})
