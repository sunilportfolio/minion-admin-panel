// Admin Dashboard JavaScript

document.addEventListener("DOMContentLoaded", () => {
  checkAdminAuth()
  loadDashboardData()
})

// Authentication check
function checkAdminAuth() {
  if (typeof window.auth !== "undefined") {
    window.auth.onAuthStateChanged((user) => {
      if (!user) {
        console.log("No user authenticated, but continuing for development")
        return
      }
      document.getElementById("adminUserName").textContent = user.displayName || user.email || "Admin"
    })
  }
}

// Load dashboard data
async function loadDashboardData() {
  try {
    await Promise.all([loadStats(), loadRecentProducts(), loadRecentServices()])
  } catch (error) {
    console.error("Error loading dashboard data:", error)
  }
}

// Load statistics
async function loadStats() {
  try {
    if (!window.db) {
      console.log("Firebase not available")
      return
    }

    // Load products stats
    const productsSnapshot = await window.db.collection("products").get()
    const totalProducts = productsSnapshot.size

    // Load services stats
    const servicesSnapshot = await window.db.collection("services").get()
    const totalServices = servicesSnapshot.size

    let activeItems = 0
    productsSnapshot.forEach((doc) => {
      const product = doc.data()
      if (product.status === "active") {
        activeItems++
      }
    })

    servicesSnapshot.forEach((doc) => {
      const service = doc.data()
      if (service.status === "active") {
        activeItems++
      }
    })

    // Update stats display
    document.getElementById("total-products").textContent = totalProducts
    document.getElementById("total-services").textContent = totalServices
    document.getElementById("active-items").textContent = activeItems
  } catch (error) {
    console.error("Error loading stats:", error)
  }
}

// Load recent products
async function loadRecentProducts() {
  try {
    if (!window.db) {
      document.getElementById("products-grid").innerHTML =
        '<div class="loading-placeholder">Firebase not connected</div>'
      return
    }

    const snapshot = await window.db.collection("products").orderBy("createdAt", "desc").limit(6).get()

    const productsGrid = document.getElementById("products-grid")

    if (snapshot.empty) {
      productsGrid.innerHTML =
        '<div class="loading-placeholder">No products found. <a href="add-product.html">Add your first product!</a></div>'
      return
    }

    productsGrid.innerHTML = ""

    snapshot.forEach((doc) => {
      const product = doc.data()
      const productCard = createProductCard(doc.id, product)
      productsGrid.appendChild(productCard)
    })
  } catch (error) {
    console.error("Error loading products:", error)
    document.getElementById("products-grid").innerHTML = '<div class="loading-placeholder">Error loading products</div>'
  }
}

// Load recent services
async function loadRecentServices() {
  try {
    if (!window.db) {
      document.getElementById("services-grid").innerHTML =
        '<div class="loading-placeholder">Firebase not connected</div>'
      return
    }

    const snapshot = await window.db.collection("services").orderBy("createdAt", "desc").limit(6).get()

    const servicesGrid = document.getElementById("services-grid")

    if (snapshot.empty) {
      servicesGrid.innerHTML =
        '<div class="loading-placeholder">No services found. <a href="add-service.html">Add your first service!</a></div>'
      return
    }

    servicesGrid.innerHTML = ""

    snapshot.forEach((doc) => {
      const service = doc.data()
      const serviceCard = createServiceCard(doc.id, service)
      servicesGrid.appendChild(serviceCard)
    })
  } catch (error) {
    console.error("Error loading services:", error)
    document.getElementById("services-grid").innerHTML = '<div class="loading-placeholder">Error loading services</div>'
  }
}

// Create product card
function createProductCard(id, product) {
  const card = document.createElement("div")
  card.className = "item-card"

  const createdDate = product.createdAt ? product.createdAt.toDate().toLocaleDateString() : "Unknown"
  const stockStatusClass = product.stockStatus ? product.stockStatus.replace("-", "_") : "in_stock"
  const priceUnitText = product.priceUnit ? product.priceUnit.replace("-", " ") : "per piece"

  card.innerHTML = `
    <img src="${product.primaryImageUrl || product.imageUrl}" alt="${product.name}" class="item-image">
    
    <div class="item-content">
      <div class="item-header">
        <h3 class="item-title">${product.name}</h3>
        <div class="item-actions">
          <button class="btn-edit" onclick="editProduct('${id}')">Edit</button>
          <button class="btn-delete" onclick="deleteProduct('${id}')">Delete</button>
        </div>
      </div>

      <div class="item-price">
        ₹${product.currentPrice} ${priceUnitText}
        ${
          product.originalPrice && product.originalPrice > product.currentPrice
            ? `<span class="original-price">₹${product.originalPrice}</span>`
            : ""
        }
      </div>

      <div class="item-details">
        ${
          product.mainCategory
            ? `<p><strong>Category:</strong> ${product.mainCategory} > ${product.category}</p>`
            : `<p><strong>Category:</strong> ${product.category}</p>`
        }
        ${product.brand ? `<p><strong>Brand:</strong> ${product.brand}</p>` : ""}
        ${product.material ? `<p><strong>Material:</strong> ${product.material}</p>` : ""}
        ${
          product.enhancedColors && product.enhancedColors.length > 0
            ? `<p><strong>Colors:</strong> ${product.enhancedColors
                .slice(0, 3)
                .map((c) => c.name)
                .join(", ")}${product.enhancedColors.length > 3 ? "..." : ""}</p>`
            : ""
        }
      </div>

      <div class="item-meta">
        <span>Added: ${createdDate}</span>
        <span class="status-badge ${stockStatusClass}">${product.stockStatus ? product.stockStatus.replace("-", " ") : "In Stock"}</span>
      </div>
    </div>
  `

  return card
}

// Create service card
function createServiceCard(id, service) {
  const card = document.createElement("div")
  card.className = "item-card"

  const createdDate = service.createdAt ? service.createdAt.toDate().toLocaleDateString() : "Unknown"
  const availabilityClass = service.availability ? service.availability.replace("-", "_") : "available"
  const priceUnitText = service.priceUnit ? service.priceUnit.replace("-", " ") : "per service"

  card.innerHTML = `
    <img src="${service.primaryImageUrl}" alt="${service.name}" class="item-image">
    
    <div class="item-content">
      <div class="item-header">
        <h3 class="item-title">${service.name}</h3>
        <div class="item-actions">
          <button class="btn-edit" onclick="editService('${id}')">Edit</button>
          <button class="btn-delete" onclick="deleteService('${id}')">Delete</button>
        </div>
      </div>

      <div class="item-price">
        ₹${service.price} ${priceUnitText}
      </div>

      <div class="item-details">
        ${
          service.mainCategory
            ? `<p><strong>Category:</strong> ${service.mainCategory} > ${service.category}</p>`
            : `<p><strong>Category:</strong> ${service.category}</p>`
        }
        <p><strong>Duration:</strong> ${service.duration}</p>
        <p><strong>Location:</strong> ${service.location.replace("-", " ")}</p>
        ${service.warranty ? `<p><strong>Warranty:</strong> ${service.warranty}</p>` : ""}
      </div>

      <div class="item-meta">
        <span>Added: ${createdDate}</span>
        <span class="status-badge ${availabilityClass}">${service.availability ? service.availability.replace("-", " ") : "Available"}</span>
      </div>
    </div>
  `

  return card
}

// Switch between sections
function switchSection(section) {
  // Hide all sections
  document.querySelectorAll(".content-section").forEach((sec) => {
    sec.classList.remove("active")
  })

  // Show selected section
  document.getElementById(`${section}-section`).classList.add("active")

  // Load data if needed
  if (section === "products") {
    loadRecentProducts()
  } else if (section === "services") {
    loadRecentServices()
  }
}

// Edit functions
function editProduct(id) {
  window.location.href = `add-product.html?edit=${id}`
}

function editService(id) {
  window.location.href = `add-service.html?edit=${id}`
}

// Delete functions
async function deleteProduct(id) {
  if (confirm("Are you sure you want to delete this product?")) {
    showLoading()
    try {
      await window.db.collection("products").doc(id).delete()
      loadRecentProducts()
      loadStats()
      alert("Product deleted successfully!")
    } catch (error) {
      console.error("Error deleting product:", error)
      alert("Error deleting product.")
    } finally {
      hideLoading()
    }
  }
}

async function deleteService(id) {
  if (confirm("Are you sure you want to delete this service?")) {
    showLoading()
    try {
      await window.db.collection("services").doc(id).delete()
      loadRecentServices()
      loadStats()
      alert("Service deleted successfully!")
    } catch (error) {
      console.error("Error deleting service:", error)
      alert("Error deleting service.")
    } finally {
      hideLoading()
    }
  }
}

// Utility functions
function showLoading() {
  document.getElementById("loading-overlay").classList.add("active")
}

function hideLoading() {
  document.getElementById("loading-overlay").classList.remove("active")
}

// Logout function
function handleLogout() {
  if (confirm("Are you sure you want to logout?")) {
    if (typeof window.auth !== "undefined") {
      window.auth
        .signOut()
        .then(() => {
          window.location.href = "index.html"
        })
        .catch((error) => {
          console.error("Logout error:", error)
        })
    } else {
      window.location.href = "index.html"
    }
  }
}

// Make functions globally available
window.switchSection = switchSection
window.editProduct = editProduct
window.editService = editService
window.deleteProduct = deleteProduct
window.deleteService = deleteService
window.handleLogout = handleLogout
