// Service Management JavaScript - Complete Implementation

document.addEventListener("DOMContentLoaded", () => {
  checkAdminAuth()
  initializeAddServicePage()
})

// Service Categories data structure
const serviceCategoriesData = {
  Installation: {
    "Smart Home Installation": [
      "Complete Smart Home Setup",
      "Smart Lighting Installation",
      "Smart Security System Setup",
      "Home Automation Installation",
      "Smart Thermostat Installation",
      "Smart Door Lock Installation",
      "Smart Camera Installation",
      "Voice Assistant Setup",
    ],
    "Electrical Installation": [
      "Wiring Installation",
      "Switch & Socket Installation",
      "Ceiling Fan Installation",
      "Light Fixture Installation",
      "Electrical Panel Upgrade",
      "Circuit Installation",
    ],
    "HVAC Installation": [
      "AC Installation",
      "Heating System Installation",
      "Ventilation Setup",
      "Duct Installation",
      "Smart HVAC Installation",
    ],
  },
  Repair: {
    "Smart Device Repair": [
      "Smart TV Repair",
      "Smart Speaker Repair",
      "Smart Lock Repair",
      "Smart Camera Repair",
      "Home Automation Troubleshooting",
      "Smart Thermostat Repair",
    ],
    "Electrical Repair": [
      "Wiring Repair",
      "Switch Repair",
      "Socket Repair",
      "Circuit Breaker Repair",
      "Electrical Troubleshooting",
    ],
    "Appliance Repair": [
      "AC Repair",
      "Refrigerator Repair",
      "Washing Machine Repair",
      "Microwave Repair",
      "Dishwasher Repair",
    ],
  },
  Maintenance: {
    "Preventive Maintenance": [
      "Annual Smart Home Checkup",
      "HVAC Maintenance",
      "Electrical System Maintenance",
      "Security System Maintenance",
      "Smart Device Updates",
    ],
    "Cleaning Services": ["AC Cleaning", "Duct Cleaning", "Electrical Panel Cleaning", "Device Cleaning"],
  },
  Consultation: {
    "Smart Home Consultation": [
      "Home Automation Planning",
      "Energy Efficiency Consultation",
      "Security Assessment",
      "Smart Home Design",
      "Technology Integration Planning",
    ],
    "Technical Consultation": [
      "Electrical System Assessment",
      "HVAC System Evaluation",
      "Network Setup Planning",
      "Device Compatibility Check",
    ],
  },
}

// Global variables for service photo management
const uploadedServicePhotos = new Map()
let servicePhotoCount = 1

// Authentication check
function checkAdminAuth() {
  if (typeof window.auth !== "undefined") {
    window.auth.onAuthStateChanged((user) => {
      if (!user) {
        console.log("No user authenticated, but continuing for development")
        return
      }
      document.getElementById("adminUserName").textContent = user.displayName || user.email || "Admin"
    })
  }
}

// Initialize add service page
function initializeAddServicePage() {
  console.log("Initializing add service page...")

  const form = document.getElementById("add-service-form")
  if (form) {
    form.addEventListener("submit", handleAddService)
  }

  setupServiceImagePreview("primary-service-photo", "primary-service-photo-preview")
  initializeRichTextEditor()

  // Initialize service category tree with a small delay
  setTimeout(() => {
    initializeServiceCategoryTree()
  }, 100)

  updateServicePhotoCounter()
  console.log("Add service page initialized")
}

// Initialize Service Category Tree
function initializeServiceCategoryTree() {
  const categoryTree = document.getElementById("service-category-tree")

  if (!categoryTree) {
    console.error("Service category tree element not found!")
    return
  }

  let html = ""

  Object.keys(serviceCategoriesData).forEach((mainCategory) => {
    html += `
      <div class="main-category-group">
        <div class="main-category-header" onclick="toggleServiceMainCategory(this)">
          <span class="category-arrow">▶</span>
          <strong>${mainCategory}</strong>
        </div>
        <div class="main-category-content">
    `

    Object.keys(serviceCategoriesData[mainCategory]).forEach((category) => {
      html += `
        <div class="category-group">
          <div class="category-header" onclick="toggleServiceCategory(this)">
            <span class="category-arrow">▶</span>
            ${category}
          </div>
          <div class="subcategories">
            ${serviceCategoriesData[mainCategory][category]
              .map(
                (subcategory) =>
                  `<div class="subcategory-item" onclick="selectServiceSubcategory(this, '${mainCategory}', '${category}', '${subcategory}')">${subcategory}</div>`,
              )
              .join("")}
          </div>
        </div>
      `
    })

    html += `
        </div>
      </div>
    `
  })

  categoryTree.innerHTML = html
  console.log("Service category tree initialized successfully")
}

// Service category functions
window.toggleServiceMainCategory = (header) => {
  const group = header.parentElement
  group.classList.toggle("expanded")
}

window.toggleServiceCategory = (header) => {
  const group = header.parentElement
  group.classList.toggle("expanded")
}

window.selectServiceSubcategory = (element, mainCategory, category, subcategory) => {
  // Remove previous selection
  document.querySelectorAll(".subcategory-item.selected").forEach((item) => {
    item.classList.remove("selected")
  })

  // Add selection to clicked item
  element.classList.add("selected")

  // Update hidden inputs
  document.getElementById("selected-service-main-category").value = mainCategory
  document.getElementById("selected-service-category").value = category
  document.getElementById("selected-service-subcategory").value = subcategory
}

// Initialize Rich Text Editor
function initializeRichTextEditor() {
  const toolbar = document.querySelector(".editor-toolbar")
  const editor = document.getElementById("service-description-editor")
  const hiddenInput = document.getElementById("service-description")

  if (!toolbar || !editor || !hiddenInput) return

  toolbar.addEventListener("click", (e) => {
    if (e.target.classList.contains("editor-btn")) {
      e.preventDefault()
      const command = e.target.dataset.command

      if (command === "fontSize") {
        document.execCommand(command, false, e.target.value)
      } else if (command === "foreColor") {
        document.execCommand(command, false, e.target.value)
      } else {
        document.execCommand(command, false, null)
      }

      e.target.classList.toggle("active")
      editor.focus()
    }
  })

  toolbar.addEventListener("change", (e) => {
    if (e.target.dataset.command) {
      const command = e.target.dataset.command
      document.execCommand(command, false, e.target.value)
      editor.focus()
    }
  })

  editor.addEventListener("input", () => {
    hiddenInput.value = editor.innerHTML
  })
}

// Service specifications functions
window.switchServiceSpecTab = (button, tabType) => {
  // Remove active class from all tabs
  document.querySelectorAll(".spec-tab").forEach((tab) => {
    tab.classList.remove("active")
  })

  // Add active class to clicked tab
  button.classList.add("active")

  // Hide all spec contents
  document.querySelectorAll(".spec-content").forEach((content) => {
    content.style.display = "none"
  })

  // Show selected spec content
  document.getElementById(tabType + "-specs").style.display = "block"
}

window.addServiceSpecRow = (specType) => {
  const tableId = specType + "-spec-table"
  const table = document.getElementById(tableId).getElementsByTagName("tbody")[0]

  const newRow = table.insertRow()
  newRow.innerHTML = `
    <td class="spec-label">
      <input type="text" placeholder="Specification name" style="width: 100%; border: none; background: transparent; font-weight: 500;">
    </td>
    <td class="spec-value">
      <input type="text" name="spec_custom_${Date.now()}" placeholder="Enter value">
      <button type="button" onclick="removeServiceSpecRow(this)" style="background: #ef4444; color: white; border: none; border-radius: 4px; padding: 4px 8px; margin-left: 8px; cursor: pointer;">×</button>
    </td>
  `
}

window.removeServiceSpecRow = (button) => {
  const row = button.closest("tr")
  row.remove()
}

// Service Photo Upload Functions
window.toggleServiceAdditionalPhotos = () => {
  const container = document.getElementById("additional-service-photos-container")
  const button = document.querySelector(".additional-photos-btn")

  if (container.style.display === "none") {
    container.style.display = "block"
    button.innerHTML = `<span>📷</span> Hide Additional Images`
  } else {
    container.style.display = "none"
    button.innerHTML = `<span>📷</span> Additional Service Images (Optional - up to 5 images total)`
  }
}

window.triggerServicePhotoUpload = (index) => {
  const photoItem = document.querySelector(`[data-index="${index}"]`)
  const fileInput = photoItem.querySelector('input[type="file"]')
  fileInput.click()
}

window.handleServicePhotoUpload = (input, index) => {
  const file = input.files[0]
  if (file) {
    const reader = new FileReader()
    reader.onload = (e) => {
      const photoItem = input.parentElement
      const photoSlot = photoItem.querySelector(".photo-slot")
      const removeBtn = photoItem.querySelector(".remove-photo-btn")
      const urlInput = photoItem.querySelector(".photo-url-input")

      // Update photo slot
      photoSlot.innerHTML = `<img src="${e.target.result}" alt="Service image ${index + 2}">`
      photoSlot.classList.add("has-image")

      // Show remove button
      removeBtn.style.display = "flex"

      // Clear URL input
      urlInput.value = ""

      // Store photo data
      uploadedServicePhotos.set(index, {
        name: file.name,
        data: e.target.result,
        file: file,
        type: "file",
      })

      updateServicePhotoCounter()
    }
    reader.readAsDataURL(file)
  }
}

window.handleServicePhotoURL = (input, index) => {
  const url = input.value.trim()
  if (url) {
    const photoItem = input.parentElement
    const photoSlot = photoItem.querySelector(".photo-slot")
    const removeBtn = photoItem.querySelector(".remove-photo-btn")
    const fileInput = photoItem.querySelector('input[type="file"]')

    // Update photo slot
    photoSlot.innerHTML = `<img src="${url}" alt="Service image ${index + 2}" onerror="this.parentElement.innerHTML='<span class=\\'upload-icon\\'>×</span><span class=\\'upload-text\\'>Invalid URL</span>'; this.parentElement.classList.remove('has-image')">`
    photoSlot.classList.add("has-image")

    // Show remove button
    removeBtn.style.display = "flex"

    // Clear file input
    fileInput.value = ""

    // Store photo data
    uploadedServicePhotos.set(index, {
      url: url,
      type: "url",
    })

    updateServicePhotoCounter()
  }
}

window.removeServicePhoto = (index) => {
  const photoItem = document.querySelector(`[data-index="${index}"]`)
  const photoSlot = photoItem.querySelector(".photo-slot")
  const removeBtn = photoItem.querySelector(".remove-photo-btn")
  const fileInput = photoItem.querySelector('input[type="file"]')
  const urlInput = photoItem.querySelector(".photo-url-input")

  // Reset photo slot
  photoSlot.innerHTML = `
    <span class="upload-icon">+</span>
    <span class="upload-text">Image ${index + 2}</span>
  `
  photoSlot.classList.remove("has-image")

  // Hide remove button
  removeBtn.style.display = "none"

  // Clear inputs
  fileInput.value = ""
  urlInput.value = ""

  // Remove from uploaded photos
  uploadedServicePhotos.delete(index)

  updateServicePhotoCounter()
}

// Handle primary service photo URL
window.handlePrimaryServicePhotoURL = () => {
  const urlInput = document.getElementById("primary-service-photo-url")
  const preview = document.getElementById("primary-service-photo-preview")
  const url = urlInput.value.trim()

  if (url) {
    preview.innerHTML = `<img src="${url}" alt="Primary service photo" onerror="this.parentElement.innerHTML='<span class=\\'empty\\'>Invalid image URL</span>'; this.parentElement.classList.add('empty')">`
    preview.classList.remove("empty")

    // Clear file input if URL is provided
    document.getElementById("primary-service-photo").value = ""
  }
}

// Update service photo counter
function updateServicePhotoCounter() {
  const counter = document.getElementById("service-photo-count")
  if (counter) {
    const totalPhotos = 1 + uploadedServicePhotos.size
    counter.textContent = totalPhotos
    servicePhotoCount = totalPhotos
  }
}

// Select booking option function
window.selectBookingOption = (element, value) => {
  // Remove selected class from all options
  document.querySelectorAll(".booking-option").forEach((option) => {
    option.classList.remove("selected")
  })

  // Add selected class to clicked option
  element.classList.add("selected")

  // Check the radio button
  const radio = element.querySelector('input[type="radio"]')
  radio.checked = true
}

// Image preview setup
function setupServiceImagePreview(inputId, previewId) {
  const input = document.getElementById(inputId)
  const preview = document.getElementById(previewId)

  if (!input || !preview) return

  preview.innerHTML = '<span class="empty">Image preview will appear here</span>'
  preview.classList.add("empty")

  input.addEventListener("change", (e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`
        preview.classList.remove("empty")

        // Clear URL input if file is selected
        const urlInput = document.getElementById(inputId + "-url")
        if (urlInput) urlInput.value = ""

        updateServicePhotoCounter()
      }
      reader.readAsDataURL(file)
    }
  })
}

// Show/hide loading overlay
function showLoading() {
  document.getElementById("loading-overlay").classList.add("active")
}

function hideLoading() {
  document.getElementById("loading-overlay").classList.remove("active")
}

// Show success message
function showSuccessMessage() {
  document.getElementById("success-message").classList.add("active")
}

// Hide success message
window.hideSuccessMessage = () => {
  document.getElementById("success-message").classList.remove("active")
  // Reset form
  document.getElementById("add-service-form").reset()

  // Reset rich text editor
  document.getElementById("service-description-editor").innerHTML = ""
  document.getElementById("service-description").value = ""

  // Reset category selection
  document.querySelectorAll(".subcategory-item.selected").forEach((item) => {
    item.classList.remove("selected")
  })
  document.getElementById("selected-service-main-category").value = ""
  document.getElementById("selected-service-category").value = ""
  document.getElementById("selected-service-subcategory").value = ""

  // Reset photos
  uploadedServicePhotos.clear()
  resetAllServicePhotos()

  // Reset booking configuration
  document.querySelector('input[name="bookingConfig"][value="enquiry-only"]').checked = true
  document.querySelectorAll(".booking-option").forEach((option) => {
    option.classList.remove("selected")
  })
  document.querySelector(".booking-option").classList.add("selected")

  // Reset image preview
  setupServiceImagePreview("primary-service-photo", "primary-service-photo-preview")
  updateServicePhotoCounter()
}

// Reset all service photos
function resetAllServicePhotos() {
  // Reset primary photo
  const primaryPreview = document.getElementById("primary-service-photo-preview")
  if (primaryPreview) {
    primaryPreview.innerHTML = '<span class="empty">Image preview will appear here</span>'
    primaryPreview.classList.add("empty")
  }

  const primaryInput = document.getElementById("primary-service-photo")
  if (primaryInput) primaryInput.value = ""

  const primaryUrl = document.getElementById("primary-service-photo-url")
  if (primaryUrl) primaryUrl.value = ""

  // Reset additional photos
  for (let i = 1; i <= 4; i++) {
    window.removeServicePhoto(i)
  }
}

// Upload image to Firebase Storage
async function uploadImage(file, folder) {
  if (typeof window.storage === "undefined") {
    console.warn("Firebase storage not available")
    return null
  }

  const timestamp = Date.now()
  const fileName = `${timestamp}_${file.name}`
  const storageRef = window.storage.ref(`${folder}/${fileName}`)

  try {
    const snapshot = await storageRef.put(file)
    const downloadURL = await snapshot.ref.getDownloadURL()
    return downloadURL
  } catch (error) {
    console.error("Error uploading image:", error)
    throw error
  }
}

// Process all service photos
async function processServicePhotos() {
  const photos = []

  // Handle primary photo (required)
  const primaryImageFile = document.getElementById("primary-service-photo").files[0]
  const primaryImageURL = document.getElementById("primary-service-photo-url").value.trim()

  if (primaryImageFile && typeof uploadImage === "function") {
    const primaryUrl = await uploadImage(primaryImageFile, "services")
    photos.push(primaryUrl)
  } else if (primaryImageURL) {
    photos.push(primaryImageURL)
  } else {
    throw new Error("Primary service image is required")
  }

  // Handle additional photos
  for (const [index, photoData] of uploadedServicePhotos.entries()) {
    if (photoData.type === "file" && photoData.file && typeof uploadImage === "function") {
      const url = await uploadImage(photoData.file, "services")
      photos.push(url)
    } else if (photoData.type === "url") {
      photos.push(photoData.url)
    }
  }

  return photos
}

// Process service specifications
function processServiceSpecifications() {
  const specifications = {
    serviceDetails: {},
    requirements: {},
    deliverables: {},
  }

  // Process service details specifications
  const serviceDetailsTable = document.getElementById("service-details-spec-table")
  if (serviceDetailsTable) {
    const serviceDetailsRows = serviceDetailsTable.querySelectorAll("tbody tr")
    serviceDetailsRows.forEach((row) => {
      const labelCell = row.querySelector(".spec-label")
      const valueCell = row.querySelector(".spec-value")

      let label = ""
      let value = ""

      // Get label
      const labelInput = labelCell.querySelector("input")
      if (labelInput) {
        label = labelInput.value.trim()
      } else {
        label = labelCell.textContent.trim()
      }

      // Get value
      const valueInput = valueCell.querySelector("input")
      const valueTextarea = valueCell.querySelector("textarea")

      if (valueInput) {
        value = valueInput.value.trim()
      } else if (valueTextarea) {
        value = valueTextarea.value.trim()
      }

      if (label && value) {
        specifications.serviceDetails[label] = value
      }
    })
  }

  // Process requirements specifications
  const requirementsTable = document.getElementById("requirements-spec-table")
  if (requirementsTable) {
    const requirementsRows = requirementsTable.querySelectorAll("tbody tr")
    requirementsRows.forEach((row) => {
      const labelCell = row.querySelector(".spec-label")
      const valueCell = row.querySelector(".spec-value")

      let label = ""
      let value = ""

      // Get label
      const labelInput = labelCell.querySelector("input")
      if (labelInput) {
        label = labelInput.value.trim()
      } else {
        label = labelCell.textContent.trim()
      }

      // Get value
      const valueInput = valueCell.querySelector("input")
      const valueTextarea = valueCell.querySelector("textarea")

      if (valueInput) {
        value = valueInput.value.trim()
      } else if (valueTextarea) {
        value = valueTextarea.value.trim()
      }

      if (label && value) {
        specifications.requirements[label] = value
      }
    })
  }

  // Process deliverables specifications
  const deliverablesTable = document.getElementById("deliverables-spec-table")
  if (deliverablesTable) {
    const deliverablesRows = deliverablesTable.querySelectorAll("tbody tr")
    deliverablesRows.forEach((row) => {
      const labelCell = row.querySelector(".spec-label")
      const valueCell = row.querySelector(".spec-value")

      let label = ""
      let value = ""

      // Get label
      const labelInput = labelCell.querySelector("input")
      if (labelInput) {
        label = labelInput.value.trim()
      } else {
        label = labelCell.textContent.trim()
      }

      // Get value
      const valueInput = valueCell.querySelector("input")
      const valueTextarea = valueCell.querySelector("textarea")

      if (valueInput) {
        value = valueInput.value.trim()
      } else if (valueTextarea) {
        value = valueTextarea.value.trim()
      }

      if (label && value) {
        specifications.deliverables[label] = value
      }
    })
  }

  return specifications
}

// Handle add service
async function handleAddService(e) {
  e.preventDefault()
  showLoading()

  try {
    const formData = new FormData(e.target)

    // Process all service photos
    const allPhotos = await processServicePhotos()
    const primaryImageUrl = allPhotos[0]
    const additionalImageUrls = allPhotos.slice(1)

    // Process service tags
    const serviceTagsString = formData.get("tags")
    const serviceTags = serviceTagsString ? serviceTagsString.split(",").map((tag) => tag.trim()) : []

    // Process service specifications
    const specifications = processServiceSpecifications()

    // Get booking configuration
    const bookingConfig = document.querySelector('input[name="bookingConfig"]:checked').value

    // Get rich text description
    const description =
      document.getElementById("service-description").value ||
      document.getElementById("service-description-editor").innerHTML

    // Prepare service data
    const serviceData = {
      name: formData.get("name"),
      description: description,
      price: Number.parseFloat(formData.get("price")),
      priceUnit: formData.get("priceUnit"),
      duration: formData.get("duration"),
      availability: formData.get("availability"),
      location: formData.get("location"),
      mainCategory: document.getElementById("selected-service-main-category").value,
      category: document.getElementById("selected-service-category").value,
      subcategory: document.getElementById("selected-service-subcategory").value,
      warranty: formData.get("warranty") || null,
      experience: formData.get("experience") || null,
      tools: formData.get("tools") || null,
      materials: formData.get("materials") || null,
      specifications: specifications,
      primaryImageUrl: primaryImageUrl,
      additionalImageUrls: additionalImageUrls,
      allPhotos: allPhotos,
      photoCount: allPhotos.length,
      serviceTags: serviceTags,
      badge: formData.get("badge") || null,
      bookingConfig: bookingConfig,
      type: "service", // Distinguish from products
      createdAt:
        typeof window.firebase !== "undefined" ? window.firebase.firestore.FieldValue.serverTimestamp() : new Date(),
      status: "active",
      bookingCount: 0,
      viewCount: 0,
      rating: 0,
      reviewCount: 0,
    }

    // Add to Firestore (if available)
    if (typeof window.db !== "undefined") {
      await window.db.collection("services").add(serviceData)
    } else {
      console.log("Service data prepared:", serviceData)
    }

    showSuccessMessage()
  } catch (error) {
    console.error("Error adding service:", error)
    alert("Error adding service: " + error.message)
  } finally {
    hideLoading()
  }
}

// Logout function
window.handleLogout = () => {
  if (confirm("Are you sure you want to logout?")) {
    if (typeof window.auth !== "undefined") {
      window.auth
        .signOut()
        .then(() => {
          window.location.href = "index.html"
        })
        .catch((error) => {
          console.error("Logout error:", error)
        })
    } else {
      window.location.href = "index.html"
    }
  }
}

// Keyboard shortcuts
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    window.hideSuccessMessage()
  }
})
